--
-- PostgreSQL database dump
--

\restrict v50Zz9uR2OmLVc2gAHvqtuGZoYROLoopH4I5OrKH1urbOLSENj844yXQMbuxT1z

-- Dumped from database version 15.19 (Debian 15.19-1.pgdg13+2)
-- Dumped by pg_dump version 15.19 (Debian 15.19-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: candidatures; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public.candidatures (
    id integer NOT NULL,
    offre_id integer NOT NULL,
    offre_titre character varying(200) NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100) NOT NULL,
    email character varying(120) NOT NULL,
    cv_filename character varying(255) NOT NULL,
    lettre_filename character varying(255) NOT NULL,
    date_postule timestamp without time zone,
    statut character varying(50)
);


ALTER TABLE public.candidatures OWNER TO dataecon;

--
-- Name: candidatures_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.candidatures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.candidatures_id_seq OWNER TO dataecon;

--
-- Name: candidatures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.candidatures_id_seq OWNED BY public.candidatures.id;


--
-- Name: certificate; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public.certificate (
    id integer NOT NULL,
    user_id integer NOT NULL,
    outil character varying(20) NOT NULL,
    niveau character varying(20) NOT NULL,
    code character varying(24) NOT NULL,
    score double precision NOT NULL,
    holder_name character varying(200) NOT NULL,
    issued_at timestamp without time zone NOT NULL,
    paiement character varying(20) DEFAULT 'a_payer'::character varying,
    wave_ref character varying(80),
    wave_tel character varying(30),
    paiement_declare_at timestamp without time zone,
    paye_at timestamp without time zone
);


ALTER TABLE public.certificate OWNER TO dataecon;

--
-- Name: certificate_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.certificate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.certificate_id_seq OWNER TO dataecon;

--
-- Name: certificate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.certificate_id_seq OWNED BY public.certificate.id;


--
-- Name: course; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public.course (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    level character varying(50),
    content text,
    created_at timestamp without time zone,
    file_path character varying(200),
    file_name character varying(100)
);


ALTER TABLE public.course OWNER TO dataecon;

--
-- Name: course_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_id_seq OWNER TO dataecon;

--
-- Name: course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.course_id_seq OWNED BY public.course.id;


--
-- Name: dataset; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public.dataset (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    file_path character varying(200),
    file_name character varying(100),
    uploaded_by integer,
    uploaded_at timestamp without time zone,
    is_private boolean DEFAULT false
);


ALTER TABLE public.dataset OWNER TO dataecon;

--
-- Name: dataset_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.dataset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_id_seq OWNER TO dataecon;

--
-- Name: dataset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.dataset_id_seq OWNED BY public.dataset.id;


--
-- Name: demandes_paiement; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public.demandes_paiement (
    id integer NOT NULL,
    user_id integer NOT NULL,
    username character varying(100) NOT NULL,
    plan_demande character varying(50) NOT NULL,
    montant integer NOT NULL,
    date_demande timestamp without time zone,
    statut character varying(20)
);


ALTER TABLE public.demandes_paiement OWNER TO dataecon;

--
-- Name: demandes_paiement_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.demandes_paiement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.demandes_paiement_id_seq OWNER TO dataecon;

--
-- Name: demandes_paiement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.demandes_paiement_id_seq OWNED BY public.demandes_paiement.id;


--
-- Name: exam_attempt; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public.exam_attempt (
    id integer NOT NULL,
    user_id integer NOT NULL,
    outil character varying(20) NOT NULL,
    niveau character varying(20) NOT NULL,
    started_at timestamp without time zone NOT NULL,
    submitted_at timestamp without time zone,
    score double precision,
    passed boolean,
    tirage text NOT NULL,
    reponses text,
    details text
);


ALTER TABLE public.exam_attempt OWNER TO dataecon;

--
-- Name: exam_attempt_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.exam_attempt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_attempt_id_seq OWNER TO dataecon;

--
-- Name: exam_attempt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.exam_attempt_id_seq OWNED BY public.exam_attempt.id;


--
-- Name: progress; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public.progress (
    id integer NOT NULL,
    user_id integer,
    course_id integer,
    completed boolean,
    progress_percent integer,
    last_accessed timestamp without time zone
);


ALTER TABLE public.progress OWNER TO dataecon;

--
-- Name: progress_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.progress_id_seq OWNER TO dataecon;

--
-- Name: progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.progress_id_seq OWNED BY public.progress.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: dataecon
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(200) NOT NULL,
    first_name character varying(80),
    last_name character varying(80),
    phone character varying(20),
    created_at timestamp without time zone,
    is_admin boolean,
    email_confirmed boolean,
    email_confirmed_at timestamp without time zone,
    last_password_reset timestamp without time zone,
    subscription_level character varying(20),
    subscription_expires_at timestamp without time zone,
    wave_payment_id character varying(100),
    is_subscription_active boolean,
    reminder_sent boolean DEFAULT false,
    reset_code character varying(5),
    reset_code_expires timestamp without time zone,
    profile_picture character varying(200)
);


ALTER TABLE public."user" OWNER TO dataecon;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: dataecon
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO dataecon;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dataecon
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: candidatures id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.candidatures ALTER COLUMN id SET DEFAULT nextval('public.candidatures_id_seq'::regclass);


--
-- Name: certificate id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.certificate ALTER COLUMN id SET DEFAULT nextval('public.certificate_id_seq'::regclass);


--
-- Name: course id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.course ALTER COLUMN id SET DEFAULT nextval('public.course_id_seq'::regclass);


--
-- Name: dataset id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.dataset ALTER COLUMN id SET DEFAULT nextval('public.dataset_id_seq'::regclass);


--
-- Name: demandes_paiement id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.demandes_paiement ALTER COLUMN id SET DEFAULT nextval('public.demandes_paiement_id_seq'::regclass);


--
-- Name: exam_attempt id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.exam_attempt ALTER COLUMN id SET DEFAULT nextval('public.exam_attempt_id_seq'::regclass);


--
-- Name: progress id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.progress ALTER COLUMN id SET DEFAULT nextval('public.progress_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: candidatures; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public.candidatures (id, offre_id, offre_titre, nom, prenom, email, cv_filename, lettre_filename, date_postule, statut) FROM stdin;
1	1	Data Analyst Junior	GAN	KADOH INNOCENT	gankadohinnocent@gmail.com	CV_20261021140549_cv_innocent.pdf	LM_20261021140549_Lettre_de_Motivation_Kadoh.pdf	2026-10-21 14:05:49.389095	En attente
\.


--
-- Data for Name: certificate; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public.certificate (id, user_id, outil, niveau, code, score, holder_name, issued_at, paiement, wave_ref, wave_tel, paiement_declare_at, paye_at) FROM stdin;
\.


--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public.course (id, title, description, level, content, created_at, file_path, file_name) FROM stdin;
14	Econométrie - Cours complet M1	Cours complet d'économétrie niveau Master 1.	Débutant	<p>Cours complet d'économétrie niveau Master 1.</p>	2026-09-09 13:02:58.00592	/app/data/pdfs/Econometrie -- m1.pdf	Econometrie -- m1.pdf
15	Introduction à l'Économétrie - Wooldridge	Cours d'introduction à l'économétrie par Wooldridge.	Débutant	<p>Introduction à l'économétrie par Wooldridge.</p>	2026-09-09 13:02:58.005924	/app/data/pdfs/20260903_115542_Introduction_a_leconometrie_wooldrid.pdf	20260903_115542_Introduction_a_leconometrie_wooldrid.pdf
16	Econométrie Appliquée avec R	Manuel des cas pratiques sur R.	Intermédiaire	<p>Manuel d'économétrie appliquée avec R.</p>	2026-09-09 13:02:58.005926	/app/data/pdfs/20260903_134410_economtrie_aplique_R.pdf	20260903_134410_economtrie_aplique_R.pdf
17	Introductory Econometrics - A Modern Approach	Manuel de référence en économétrie par Wooldridge.	Intermédiaire	<p>Introductory Econometrics par Wooldridge.</p>	2026-09-09 13:02:58.005927	/app/data/pdfs/Introductory Econometrics- A modern Approach.pdf	Introductory Econometrics- A modern Approach.pdf
18	Econometric Methods - 4th Edition	Méthodes économétriques avancées.	Avancé	<p>Econometric Methods - 4ème édition.</p>	2026-09-09 13:02:58.005927	/app/data/pdfs/Econometric Methods, Fourth Edition ( PDFDrive ).pdf	Econometric Methods, Fourth Edition ( PDFDrive ).pdf
19	Greene - Econometric Analysis 8th Edition	Analyse économétrique avancée.	Avancé	<p>Greene Econometric Analysis 8th Edition.</p>	2026-09-09 13:02:58.005928	/app/data/pdfs/Greene_Econometric_Analysis _8th Ed-3.pdf	Greene_Econometric_Analysis _8th Ed-3.pdf
20	Maddala - Introduction to Econometrics	Introduction à l'économétrie par Maddala.	Intermédiaire	<p>Maddala Introduction to Econometrics.</p>	2026-09-09 13:02:58.005929	/app/data/pdfs/Maddala-Introduction to Econometrics.pdf	Maddala-Introduction to Econometrics.pdf
21	Econométrie - 10e édition	Cours complet d'économétrie.	Intermédiaire	<p>Économétrie 10e édition.</p>	2026-09-09 13:02:58.00593	/app/data/pdfs/Econométrie 10e edition.pdf	Econométrie 10e edition.pdf
22	Econométrie - Cours et Exercices	Cours d'économétrie avec exercices corrigés.	Intermédiaire	<p>Econométrie cours et exercices.</p>	2026-09-09 13:02:58.00593	/app/data/pdfs/econometrie cours et exo.pdf	econometrie cours et exo.pdf
23	Analyse des Séries Temporelles - Tsay	Analyse des séries temporelles financières.	Avancé	<p>Analysis of Financial Time Series par Tsay.</p>	2026-09-09 13:02:58.005931	/app/data/pdfs/Partager Tsay_Analysis_of_Financial_Time_Series.pdf	Partager Tsay_Analysis_of_Financial_Time_Series.pdf
24	100 fiches pour comprendre les sciences économiques	Fiches de synthèse en sciences économiques.	Débutant	<p>100 fiches pour comprendre les sciences économiques.</p>	2026-09-09 13:02:58.005932	/app/data/pdfs/100 fiches pour comprendre les sciences écomomiques.pdf	100 fiches pour comprendre les sciences écomomiques.pdf
25	Analyse et gestion du risque bancaire	Cours sur le risque bancaire.	Avancé	<p>Analyse et gestion du risque bancaire.</p>	2026-09-09 13:02:58.005933	/app/data/pdfs/Analyse et gestion du risque bancaire.pdf	Analyse et gestion du risque bancaire.pdf
26	Banques centrales - Nouveaux outils de politique monétaire	Les nouveaux outils de politique monétaire.	Avancé	<p>Banques centrales et politique monétaire.</p>	2026-09-09 13:02:58.005934	/app/data/pdfs/Banques centrales les nouveaux outils de politique monétaire.pdf	Banques centrales les nouveaux outils de politique monétaire.pdf
27	Comptabilité analytique	Cours de comptabilité analytique.	Débutant	<p>Comptabilité analytique.</p>	2026-09-09 13:02:58.005935	/app/data/pdfs/Comptabilité analytique.pdf	Comptabilité analytique.pdf
28	L'optimisation mathématique pour les fonctions à plusieurs variables	Cours d'optimisation mathématique.	Intermédiaire	<p>Optimisation mathématique pour les fonctions à plusieurs variables.</p>	2026-09-09 13:02:58.005936	/app/data/pdfs/L'optimisation mathématique pour les fonctions à plusieurs variables..pdf	L'optimisation mathématique pour les fonctions à plusieurs variables..pdf
29	Les théories économiques et leurs applications	Théories économiques et applications.	Débutant	<p>Les théories économiques et leurs applications.</p>	2026-09-09 13:02:58.005936	/app/data/pdfs/Les théories économiques et leurs applications.pdf	Les théories économiques et leurs applications.pdf
30	Mathématiques financières	Cours de mathématiques financières.	Intermédiaire	<p>Mathématiques financières.</p>	2026-09-09 13:02:58.005937	/app/data/pdfs/Mathématiques financières.pdf	Mathématiques financières.pdf
31	Programmation linéaire et Optimisation	Cours de programmation linéaire.	Intermédiaire	<p>Programmation linéaire et Optimisation.</p>	2026-09-09 13:02:58.005938	/app/data/pdfs/Programmation linéaire et Optimisation.pdf	Programmation linéaire et Optimisation.pdf
32	Théorie des jeux	Introduction à la théorie des jeux.	Intermédiaire	<p>Théorie des jeux.</p>	2026-09-09 13:02:58.005939	/app/data/pdfs/théorie des jeux.pdf	théorie des jeux.pdf
33	Théorie des jeux et économie de l'information	Théorie des jeux appliquée à l'économie.	Avancé	<p>Théorie des jeux et économie de l'information.</p>	2026-09-09 13:02:58.00594	/app/data/pdfs/théorie des jeux et économie de l'information.pdf	théorie des jeux et économie de l'information.pdf
34	Économie de l'environnement et économie écologique	Économie de l'environnement.	Avancé	<p>Économie de l'environnement et économie écologique.</p>	2026-09-09 13:02:58.005941	/app/data/pdfs/Économie de l'environnement et économie écologique.pdf	Économie de l'environnement et économie écologique.pdf
35	Économétrie Appliquée - Manuel des cas pratiques sur EViews	Manuel des cas pratiques sur EViews.	Intermédiaire	<p>Économétrie Appliquée - Manuel des cas pratiques sur EViews.</p>	2026-09-09 13:02:58.005942	/app/data/pdfs/Économétrie_Appliquée_Manuel_des_cas_pratiques_sur_EViews_Jonas.pdf	Économétrie_Appliquée_Manuel_des_cas_pratiques_sur_EViews_Jonas.pdf
\.


--
-- Data for Name: dataset; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public.dataset (id, name, description, file_path, file_name, uploaded_by, uploaded_at, is_private) FROM stdin;
\.


--
-- Data for Name: demandes_paiement; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public.demandes_paiement (id, user_id, username, plan_demande, montant, date_demande, statut) FROM stdin;
1	1	admin	Premium	15000	2026-10-22 14:42:54.323145	En attente
2	1	admin	Premium	15000	2026-10-22 14:56:06.07032	En attente
\.


--
-- Data for Name: exam_attempt; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public.exam_attempt (id, user_id, outil, niveau, started_at, submitted_at, score, passed, tirage, reponses, details) FROM stdin;
\.


--
-- Data for Name: progress; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public.progress (id, user_id, course_id, completed, progress_percent, last_accessed) FROM stdin;
8	1	35	f	0	2026-09-09 13:07:57.80368
9	1	15	f	0	2026-09-09 13:10:28.183177
10	1	14	f	0	2026-09-10 08:46:04.81313
11	1	16	f	0	2026-09-10 14:36:28.686004
12	8	19	f	0	2026-09-11 09:10:50.903067
13	8	24	f	0	2026-09-11 09:11:03.640729
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: dataecon
--

COPY public."user" (id, username, email, password_hash, first_name, last_name, phone, created_at, is_admin, email_confirmed, email_confirmed_at, last_password_reset, subscription_level, subscription_expires_at, wave_payment_id, is_subscription_active, reminder_sent, reset_code, reset_code_expires, profile_picture) FROM stdin;
1	admin	admin@dataecon.ci	pbkdf2:sha256:600000$WXdFpOsLBkj4KlCc$52f19cc2097a3620adec3bac9ad433ceea8422ad9f898d4c2c4a9f5d75463f4a	Admin	DataEcon	\N	2026-09-03 14:56:12.2636	t	t	2026-09-03 14:56:11.987895	\N	free	\N	\N	f	f	\N	\N	\N
9	kadoh	gankadoh@gmail.com	pbkdf2:sha256:600000$HtVPmj9vMVixj9VK$127cfcfdbd0d5a3fa1416a9e2f1dab8eb0e0174c50bcbf4fab2cbbd0d7795812	Kadoh	Gan	+2250502245503	2026-09-09 10:13:55.153933	f	t	2026-09-09 10:14:42.869581	\N	free	\N	\N	f	f	\N	\N	\N
8	Innocent	gankadohinnocent@gmail.com	pbkdf2:sha256:600000$0fjtRx6BGchRNvFl$b73e3baa5372d48c3be1f009e616397c325acd3e236577668faa6414a5acb6b2	Kadoh	Gan	+2250502245503	2026-09-09 10:10:19.85925	f	t	2026-09-09 10:10:46.220084	\N	free	\N	\N	f	f	\N	\N	\N
\.


--
-- Name: candidatures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.candidatures_id_seq', 1, true);


--
-- Name: certificate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.certificate_id_seq', 1, false);


--
-- Name: course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.course_id_seq', 35, true);


--
-- Name: dataset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.dataset_id_seq', 1, true);


--
-- Name: demandes_paiement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.demandes_paiement_id_seq', 2, true);


--
-- Name: exam_attempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.exam_attempt_id_seq', 1, false);


--
-- Name: progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.progress_id_seq', 13, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dataecon
--

SELECT pg_catalog.setval('public.user_id_seq', 9, true);


--
-- Name: candidatures candidatures_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.candidatures
    ADD CONSTRAINT candidatures_pkey PRIMARY KEY (id);


--
-- Name: certificate certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT certificate_pkey PRIMARY KEY (id);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (id);


--
-- Name: dataset dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_pkey PRIMARY KEY (id);


--
-- Name: demandes_paiement demandes_paiement_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.demandes_paiement
    ADD CONSTRAINT demandes_paiement_pkey PRIMARY KEY (id);


--
-- Name: exam_attempt exam_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.exam_attempt
    ADD CONSTRAINT exam_attempt_pkey PRIMARY KEY (id);


--
-- Name: progress progress_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.progress
    ADD CONSTRAINT progress_pkey PRIMARY KEY (id);


--
-- Name: certificate uq_cert_user_course; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT uq_cert_user_course UNIQUE (user_id, outil, niveau);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user user_username_key; Type: CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


--
-- Name: ix_certificate_code; Type: INDEX; Schema: public; Owner: dataecon
--

CREATE UNIQUE INDEX ix_certificate_code ON public.certificate USING btree (code);


--
-- Name: ix_certificate_user_id; Type: INDEX; Schema: public; Owner: dataecon
--

CREATE INDEX ix_certificate_user_id ON public.certificate USING btree (user_id);


--
-- Name: ix_exam_attempt_user_id; Type: INDEX; Schema: public; Owner: dataecon
--

CREATE INDEX ix_exam_attempt_user_id ON public.exam_attempt USING btree (user_id);


--
-- Name: certificate certificate_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT certificate_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: dataset dataset_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public."user"(id);


--
-- Name: demandes_paiement demandes_paiement_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.demandes_paiement
    ADD CONSTRAINT demandes_paiement_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: exam_attempt exam_attempt_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.exam_attempt
    ADD CONSTRAINT exam_attempt_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: progress progress_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.progress
    ADD CONSTRAINT progress_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(id);


--
-- Name: progress progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dataecon
--

ALTER TABLE ONLY public.progress
    ADD CONSTRAINT progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

\unrestrict v50Zz9uR2OmLVc2gAHvqtuGZoYROLoopH4I5OrKH1urbOLSENj844yXQMbuxT1z

