from __future__ import annotations

import typing as t

from sqlglot import exp
from sqlglot.typing import EXPRESSION_METADATA, annotate_int_as_double

if t.TYPE_CHECKING:
    from sqlglot.optimizer.annotate_types import TypeAnnotator


DATETIME_WITHOUT_TZ = {
    exp.DType.DATE,
    exp.DType.TIMESTAMP,
    exp.DType.TIMESTAMPNTZ,
    exp.DType.TIMESTAMP_S,
    exp.DType.TIMESTAMP_MS,
    exp.DType.TIMESTAMP_NS,
}


def _annotate_at_time_zone(self: TypeAnnotator, expression: exp.AtTimeZone) -> exp.Expr:
    this = expression.this

    if this.is_type(*DATETIME_WITHOUT_TZ):
        return self._set_type(expression, exp.DType.TIMESTAMPTZ)
    if this.is_type(exp.DType.TIMESTAMPTZ):
        return self._set_type(expression, exp.DType.TIMESTAMP)
    if this.is_type(exp.DType.TIMETZ):
        return self._set_type(expression, exp.DType.TIMETZ)

    return self._set_type(expression, exp.DType.UNKNOWN)


def _annotate_date_trunc(
    self: TypeAnnotator, expression: exp.DateTrunc | exp.TimestampTrunc
) -> exp.Expr:
    if expression.this.is_type(
        exp.DType.DATE,
        exp.DType.TIMESTAMP_S,
        exp.DType.TIMESTAMP_MS,
        exp.DType.TIMESTAMP_NS,
    ):
        return self._set_type(expression, exp.DType.TIMESTAMP)

    return self._set_type(expression, expression.this.type)


def _annotate_floor_ceil(self: TypeAnnotator, expression: exp.Expr) -> exp.Expr:
    if expression.this.is_type(exp.DType.DECIMAL):
        return self._set_type(expression, exp.DType.UNKNOWN)
    return annotate_int_as_double(self, expression)


def _annotate_add_sub(self: TypeAnnotator, expression: exp.Add | exp.Sub) -> exp.Expr:
    self._annotate_binary(expression)
    left, right = expression.left, expression.right

    if isinstance(expression, exp.Add) and left.is_type(exp.DType.INTERVAL):
        left, right = right, left

    if right.is_type(exp.DType.INTERVAL):
        if left.is_type(*DATETIME_WITHOUT_TZ):
            self._set_type(expression, exp.DType.TIMESTAMP)
        elif left.is_type(exp.DType.TIME, exp.DType.TIMETZ, exp.DType.TIMESTAMPTZ):
            self._set_type(expression, left.type)

    return expression


EXPRESSION_METADATA = {
    **EXPRESSION_METADATA,
    **{
        expr_type: {"returns": exp.DType.BIGINT}
        for expr_type in {
            exp.BitLength,
            exp.DateDiff,
            exp.Day,
            exp.DayOfMonth,
            exp.DayOfWeek,
            exp.DayOfWeekIso,
            exp.DayOfYear,
            exp.Extract,
            exp.Hour,
            exp.Length,
            exp.Minute,
            exp.Month,
            exp.Quarter,
            exp.Second,
            exp.Week,
            exp.Year,
        }
    },
    **{
        expr_type: {"returns": exp.DType.INT128}
        for expr_type in {
            exp.CountIf,
            exp.Factorial,
        }
    },
    **{
        expr_type: {"returns": exp.DType.DOUBLE}
        for expr_type in {
            exp.Atan2,
            exp.JarowinklerSimilarity,
            exp.TimeToUnix,
        }
    },
    **{
        expr_type: {"returns": exp.DType.VARCHAR}
        for expr_type in {
            exp.Format,
            exp.Reverse,
            exp.Decode,
        }
    },
    **{
        expr_type: {"returns": exp.DType.VARBINARY}
        for expr_type in {
            exp.Encode,
            exp.Unhex,
        }
    },
    **{
        expr_type: {"annotator": _annotate_floor_ceil}
        for expr_type in {
            exp.Ceil,
            exp.Floor,
        }
    },
    **{
        expr_type: {"annotator": lambda self, e: self._annotate_by_args(e, "this")}
        for expr_type in {
            exp.BitwiseAndAgg,
            exp.BitwiseOrAgg,
            exp.BitwiseXorAgg,
            exp.PercentileDisc,
            exp.Mode,
        }
    },
    exp.Add: {"annotator": _annotate_add_sub},
    exp.Sub: {"annotator": _annotate_add_sub},
    exp.AtTimeZone: {"annotator": _annotate_at_time_zone},
    exp.DateBin: {"annotator": lambda self, e: self._annotate_by_args(e, "expression")},
    exp.DateTrunc: {"annotator": _annotate_date_trunc},
    exp.TimestampTrunc: {"annotator": _annotate_date_trunc},
    exp.Localtimestamp: {"returns": exp.DType.TIMESTAMP},
    exp.ToDays: {"returns": exp.DType.INTERVAL},
    exp.TimeFromParts: {"returns": exp.DType.TIME},
    exp.TimestampFromParts: {"returns": exp.DType.TIMESTAMP},
}
